"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown, ChevronLeft, Filter, Search, Venus } from "lucide-react";
import { auth } from "@/lib/firebase";

type Pratica = {
  codigo: "A" | "B" | "C" | "D";
  titulo: string;
  peso: number;
  elegiveis: number;
  atingidos: number;
  percentual: number | null;
  pontos: number | null;
  disponivel: boolean;
  descricao: string;
};

type Paciente = {
  id: string;
  nome: string;
  cpf?: string;
  cns?: string;
  dataNascimento?: string;
  idade?: number;
  sexo?: string;
  identidadeGenero?: string;
  microarea?: string;
  praticas: { A: boolean; B: boolean; C: boolean; D: boolean };
  detalhes: { A?: string; B?: string; C?: string; D?: string };
  pontuacaoDisponivel: number;
};

type Resultado = {
  sucesso: boolean;
  possuiDados?: boolean;
  completo?: boolean;
  motivoIncompleto?: string;
  totalElegiveis?: number;
  pontuacao?: number | null;
  pontuacaoParcial?: number;
  pontosDisponiveis?: number;
  classificacao?: string;
  praticas?: Record<"A" | "B" | "C" | "D", Pratica>;
  pacientes?: Paciente[];
  mensagem?: string;
};

function formatarPercentual(valor: number | null | undefined) {
  return valor == null
    ? "N/A"
    : `${valor.toLocaleString("pt-BR", {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      })}%`;
}

function nivelPrioridade(pendentes: number, elegiveis: number) {
  if (elegiveis <= 0 || pendentes <= 0) return null;

  const percentualPendente = (pendentes / elegiveis) * 100;

  if (percentualPendente >= 50) return "Prioridade";
  if (percentualPendente >= 25) return "Atenção";
  return null;
}

function praticaAplicavel(
  idade: number | undefined,
  codigo: "A" | "B" | "C" | "D",
) {
  if (idade == null) return false;

  if (codigo === "A") return idade >= 25 && idade <= 64;
  if (codigo === "B") return idade >= 9 && idade <= 14;
  if (codigo === "C") return idade >= 14 && idade <= 69;
  return idade >= 50 && idade <= 69;
}

export default function C7Page() {
  const router = useRouter();
  const [dados, setDados] = useState<Resultado | null>(null);
  const [erro, setErro] = useState("");
  const [busca, setBusca] = useState("");
  const [microarea, setMicroarea] = useState("Todas");
  const [pratica, setPratica] = useState("Todas");
  const [aberto, setAberto] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(true);

 useEffect(() => {
  let cancelado = false;
  let iniciou = false;

  const pararObservador = auth.onIdTokenChanged(async (usuario) => {
    if (cancelado || iniciou) return;

    // Aguarda o Firebase restaurar a sessão antes de verificar
    // se o usuário realmente está sem autenticação.
    if (!usuario) return;

    iniciou = true;

    try {
      setCarregando(true);

      const token = await usuario.getIdToken();

      const resposta = await fetch("/api/indicadores/c7", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const json = await resposta.json();

      if (cancelado) return;

      if (resposta.status === 401) {
        router.replace("/login");
        return;
      }

      if (!resposta.ok || !json.sucesso) {
        setErro(json.mensagem || "Erro ao carregar o C7.");
        return;
      }

      setDados(json);
    } catch (e) {
      console.error("Erro ao carregar C7:", e);

      if (!cancelado) {
        setErro("Não foi possível carregar o C7.");
      }
    } finally {
      if (!cancelado) {
        setCarregando(false);
      }
    }
  });

  return () => {
    cancelado = true;
    pararObservador();
  };
}, [router]);

  const pacientes = useMemo(() => {
    const lista = dados?.pacientes ?? [];
    const termo = busca.trim().toLowerCase();
    const praticasFiltro = dados?.praticas;

    return lista.filter((p) => {
      const bateBusca =
        !termo ||
        p.nome.toLowerCase().includes(termo) ||
        (p.cpf || "").includes(termo) ||
        (p.cns || "").includes(termo);

      const bateMicroarea =
        microarea === "Todas" || (p.microarea || "Sem microárea") === microarea;

      const praticaSelecionada =
        pratica === "Todas"
          ? null
          : praticasFiltro?.[pratica as keyof typeof praticasFiltro];

      const codigoPratica =
        pratica === "Todas"
          ? null
          : (pratica as "A" | "B" | "C" | "D");

      const batePratica =
        pratica === "Todas" ||
        (praticaSelecionada?.disponivel === true &&
          codigoPratica !== null &&
          praticaAplicavel(p.idade, codigoPratica) &&
          p.praticas[codigoPratica] === false);

      return bateBusca && bateMicroarea && batePratica;
    });
  }, [dados, busca, microarea, pratica]);

  const microareas = useMemo(() => {
    return Array.from(
      new Set(
        (dados?.pacientes ?? []).map((p) => p.microarea || "Sem microárea")
      )
    ).sort();
  }, [dados]);

  if (carregando) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#F7FAFC]">
        <div className="h-9 w-9 animate-spin rounded-full border-4 border-[#10B981]/20 border-t-[#10B981]" />
      </main>
    );
  }

  if (erro) {
    return (
      <main className="min-h-screen bg-[#F7FAFC] p-6 text-[#003B8E]">
        <button
          onClick={() => router.back()}
          className="mb-5 flex items-center gap-1 text-xs font-semibold text-[#003B8E]"
        >
          <ChevronLeft size={15} /> Voltar
        </button>
        <section className="rounded-2xl bg-white p-8 text-center shadow-sm">
          <p className="font-bold">Não foi possível carregar o C7</p>
          <p className="mt-2 text-xs text-gray-500">{erro}</p>
        </section>
      </main>
    );
  }

  if (!dados?.possuiDados) {
    return (
      <main className="min-h-screen bg-[#F7FAFC] text-[#003B8E]">
        <header className="relative isolate overflow-hidden rounded-b-[28px] border border-emerald-200/60 bg-gradient-to-br from-[#009C3B]/95 via-[#00A9E8]/85 to-[#F2C300]/85 px-5 py-5 text-white shadow-[0_10px_24px_rgba(0,156,59,0.16),0_4px_10px_rgba(0,59,142,0.10)] backdrop-blur-md">
          <div className="pointer-events-none absolute -left-10 -top-14 h-28 w-28 rounded-full bg-white/15 blur-2xl" />
          <div className="pointer-events-none absolute right-20 -top-12 h-32 w-32 rounded-full bg-[#F2C300]/20 blur-3xl" />
          <div className="relative pr-20">
            <button onClick={() => router.back()} className="flex items-center gap-2 text-xs font-bold text-white/95">
              <ChevronLeft size={14} /> Voltar
            </button>
            <div className="mt-4">
              <p className="text-[9px] font-semibold uppercase tracking-wider text-white/85">Indicadores APS Brasil 360</p>
              <h1 className="mt-1 text-lg font-extrabold">C7 — Cuidado da Mulher</h1>
              <p className="mt-1 text-[10px] text-white/90">Prevenção do câncer, HPV e saúde sexual e reprodutiva</p>
            </div>
          </div>
          <img src="/brasil360-logo-header.png" alt="Brasil 360" width={88} height={88} className="absolute right-5 top-1/2 h-16 w-16 -translate-y-1/2 rounded-2xl object-cover shadow-[0_8px_18px_rgba(0,59,142,0.22)] ring-1 ring-white/50 sm:h-20 sm:w-20" />
        </header>
        <section className="p-6">
          <div className="rounded-2xl bg-white p-8 text-center shadow-sm">
            <Venus className="mx-auto text-[#003B8E]" />
            <p className="mt-3 text-sm font-bold">Ainda não há dados para o C7</p>
            <p className="mt-1 text-xs text-gray-500">
              Importe o relatório temático Saúde da mulher do e-SUS PEC.
            </p>
          </div>
        </section>
      </main>
    );
  }

  const praticas = dados.praticas;
  const incompleto = dados.completo === false;

  return (
    <main className="min-h-screen bg-[#F7FAFC] text-[#003B8E]">
      <header className="relative isolate overflow-hidden rounded-b-[28px] border border-emerald-200/60 bg-gradient-to-br from-[#009C3B]/95 via-[#00A9E8]/85 to-[#F2C300]/85 px-5 py-5 text-white shadow-[0_10px_24px_rgba(0,156,59,0.16),0_4px_10px_rgba(0,59,142,0.10)] backdrop-blur-md">
        <div className="pointer-events-none absolute -left-10 -top-14 h-28 w-28 rounded-full bg-white/15 blur-2xl" />
        <div className="pointer-events-none absolute right-20 -top-12 h-32 w-32 rounded-full bg-[#F2C300]/20 blur-3xl" />

        <div className="relative pr-20">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-xs font-bold text-white/95"
          >
            <ChevronLeft size={14} /> Voltar
          </button>

          <div className="mt-4">
            <p className="text-[9px] font-semibold uppercase tracking-wider text-white/85">
              Indicadores APS Brasil 360
            </p>
            <h1 className="mt-1 text-lg font-extrabold">C7 — Cuidado da Mulher</h1>
            <p className="mt-1 text-[10px] text-white/90">
              Prevenção do câncer, HPV e saúde sexual e reprodutiva
            </p>
          </div>
        </div>

        <img
          src="/brasil360-logo-header.png"
          alt="Brasil 360"
          width={88}
          height={88}
          className="absolute right-5 top-1/2 h-16 w-16 -translate-y-1/2 rounded-2xl object-cover shadow-[0_8px_18px_rgba(0,59,142,0.22)] ring-1 ring-white/50 sm:h-20 sm:w-20"
        />
      </header>

      <section className="p-4 pt-6 md:p-6">
        {incompleto && (
          <div className="mb-3 rounded-xl border border-[#FDE68A] bg-[#FFFBEB] px-4 py-3 text-xs text-[#92400E]">
            <strong>Cálculo preliminar:</strong> este relatório foi exportado de
            14 a 69 anos. A prática B (HPV, 9 a 14 anos) ficou sem denominador.
            Para o indicador completo, importe um C7 de 9 a 69 anos.
          </div>
        )}

        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-[#9EDFF2] bg-gradient-to-br from-[#EAF7FC] via-white to-[#D7F1FA] p-5 shadow-[0_6px_14px_rgba(0,169,232,0.12),0_2px_5px_rgba(0,0,0,0.05)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_20px_rgba(0,169,232,0.18)]">
            <p className="text-[8px] font-medium text-[#39708A]">Resultado C7</p>
            <p className="mt-1 text-3xl font-extrabold text-[#003B8E]">
              {dados.pontuacao == null
                ? `${formatarPercentual(dados.pontuacaoParcial)}*`
                : formatarPercentual(dados.pontuacao)}
            </p>
            <p className="text-[9px] font-semibold text-[#003B8E]">{dados.classificacao}</p>
          </div>
          <div className="rounded-2xl border border-[#A7E6C0] bg-gradient-to-br from-[#ECFDF3] via-white to-[#DDF7E7] p-5 shadow-[0_6px_14px_rgba(0,156,59,0.12),0_2px_5px_rgba(0,0,0,0.05)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_20px_rgba(0,156,59,0.18)]">
            <p className="text-[8px] font-medium text-[#39705A]">Elegíveis</p>
            <p className="mt-1 text-3xl font-extrabold text-[#003B8E]">{dados.totalElegiveis}</p>
            <p className="text-[9px] text-[#39705A]">pessoas 9–69 anos</p>
          </div>
        </section>

        <section className="mt-3 rounded-2xl bg-white p-4 shadow-sm">
          <div className="mb-1 flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-bold">Onde concentrar o acompanhamento</h2>
              <p className="mt-1 text-[8px] text-gray-400">
                Toque em uma prática para mostrar somente quem ainda não a atingiu.
              </p>
            </div>
            <Filter size={15} className="text-[#003B8E]" />
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {(["A", "B", "C", "D"] as const).map((codigo) => {
              const p = praticas?.[codigo];
              if (!p) return null;

              const pendentes = Math.max(p.elegiveis - p.atingidos, 0);
              const prioridade = nivelPrioridade(pendentes, p.elegiveis);

              return (
                <button
                  key={codigo}
                  type="button"
                  onClick={() => setPratica(pratica === codigo ? "Todas" : codigo)}
                  className={`rounded-xl border p-3 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_16px_rgba(0,59,142,0.11)] ${
                    pratica === codigo
                      ? "border-[#7C3AED] bg-[#EAF7FC] shadow-[0_4px_12px_rgba(124,58,237,0.12)]"
                      : codigo === "A"
                        ? "border-[#9EDFF2] bg-gradient-to-br from-[#EAF7FC] to-[#D7F1FA]"
                        : codigo === "B"
                          ? "border-[#A7E6C0] bg-gradient-to-br from-[#ECFDF3] to-[#DDF7E7]"
                          : codigo === "C"
                            ? "border-[#F5D66A] bg-gradient-to-br from-[#FFF9E5] to-[#FFF1B8]"
                            : "border-[#FECACA] bg-gradient-to-br from-[#FFF1F2] to-[#FFE4E6]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-[9px] font-bold text-[#003B8E]">
                      {codigo} • {p.titulo}
                    </p>

                    {prioridade === "Prioridade" && (
                      <span className="shrink-0 rounded-full bg-[#FEE2E2] px-2 py-0.5 text-[7px] font-extrabold text-[#DC2626]">
                        Prioridade
                      </span>
                    )}

                    {prioridade === "Atenção" && (
                      <span className="shrink-0 rounded-full bg-[#FEF3C7] px-2 py-0.5 text-[7px] font-extrabold text-[#D97706]">
                        Atenção
                      </span>
                    )}
                  </div>

                  <p className="mt-1 text-lg font-extrabold text-[#003B8E]">
                    {pendentes}
                  </p>
                  <p className="text-[8px] text-gray-400">pendentes</p>

                  <div className="mt-2 h-1.5 rounded-full bg-white/80">
                    <div
                      className={`h-1.5 rounded-full ${
                        codigo === "A"
                          ? "bg-[#00A9E8]"
                          : codigo === "B"
                            ? "bg-[#009C3B]"
                            : codigo === "C"
                              ? "bg-[#F2C300]"
                              : "bg-[#003B8E]"
                      }`}
                      style={{ width: `${Math.min(p.percentual ?? 0, 100)}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="mt-3 rounded-2xl bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2">
            <Search size={14} className="text-[#003B8E]" />
            <input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Buscar nome ou CPF"
              className="w-full rounded-lg border border-[#DDEAF2] px-3 py-2 text-xs outline-none focus:border-[#00A9E8]"
            />
          </div>

          <div className="mt-2 grid grid-cols-2 gap-2">
            <select
              value={microarea}
              onChange={(e) => setMicroarea(e.target.value)}
              className="rounded-lg border border-[#DDEAF2] px-3 py-2 text-[10px]"
            >
              <option>Todas</option>
              {microareas.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>

            <div className="flex items-center justify-between rounded-lg border border-[#DDEAF2] bg-[#F7FAFC] px-3 py-2">
              <span className="text-[8px] text-gray-500">
                {pratica === "Todas"
                  ? "Todas as práticas"
                  : `Filtro ativo: prática ${pratica}`}
              </span>
              {pratica !== "Todas" && (
                <button
                  type="button"
                  onClick={() => setPratica("Todas")}
                  className="text-[8px] font-extrabold text-[#003B8E]"
                >
                  Limpar filtro
                </button>
              )}
            </div>
          </div>
        </section>

        <section className="mt-3 space-y-2">
          {pacientes.map((paciente) => {
            const expandido = aberto === paciente.id;

            return (
              <div key={paciente.id} className="overflow-hidden rounded-xl bg-white shadow-sm">
                <button
                  type="button"
                  onClick={() => setAberto(expandido ? null : paciente.id)}
                  className="flex w-full items-center justify-between px-4 py-3 text-left"
                >
                  <div>
                    <p className="text-[9px] font-bold">{paciente.nome}</p>
                    <p className="mt-0.5 text-[7px] text-gray-400">
                      {paciente.idade} anos • Microárea {paciente.microarea || "—"}
                    </p>
                  </div>
                  <ChevronDown
                    size={14}
                    className={`text-[#003B8E] transition ${expandido ? "rotate-180" : ""}`}
                  />
                </button>

                {expandido && (
                  <div className="border-t border-gray-100 px-4 py-3">
                    <div className="grid grid-cols-2 gap-2">
                      {(["A", "B", "C", "D"] as const).map((codigo) => {
                        const aplicavel = praticaAplicavel(paciente.idade, codigo);
                        const atingida = paciente.praticas[codigo];

                        return (
                          <div key={codigo} className="rounded-lg bg-[#F7FAFC] p-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[8px] font-bold">{codigo}</span>

                              <span
                                className={`text-[8px] font-bold ${
                                  !aplicavel
                                    ? "text-gray-400"
                                    : atingida
                                      ? "text-emerald-600"
                                      : "text-red-500"
                                }`}
                              >
                                {!aplicavel
                                  ? "Não aplicável"
                                  : atingida
                                    ? "Atingida"
                                    : "Pendente"}
                              </span>
                            </div>

                            <p className="mt-1 text-[7px] text-gray-500">
                              {paciente.detalhes[codigo]}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </section>

        {pacientes.length === 0 && (
          <div className="mt-4 rounded-xl bg-white p-6 text-center text-xs text-gray-400">
            Nenhuma pessoa encontrada com os filtros atuais.
          </div>
        )}

        {incompleto && (
          <p className="mt-4 text-[8px] leading-relaxed text-gray-400">
            * Pontuação parcial disponível: {dados.pontuacaoParcial?.toFixed(1)} de{" "}
            {dados.pontosDisponiveis} pontos. Não é uma classificação oficial
            enquanto a prática B não possuir denominador.
          </p>
        )}
      </section>
    </main>
  );
}
